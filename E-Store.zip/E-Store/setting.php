<?php
$con = mysqli_connect("localhost:3308", "root", "", "estoremodel")or die($mysqli_error($con));
error_reporting(E_ALL ^ E_NOTICE);
session_start();
if (!isset($_SESSION['email'])) {
    header('location: index.php');
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="css/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>
        <style>
            footer {
  background-color: #555;
  color: #bbb;
  line-height: 1.5;
  bottom: 0;
  position: absolute;
  width: 100%;
}
        </style>
        <title>Settings || E-Store</title>
    </head>
    <body>
        <div class="navbar  navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>                        
            </button>
            <a class="navbar-brand active active" href="home.php">E-Store</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
                <li class="active"><a href = "setting.php"><span class = "glyphicon glyphicon-cog"></span> Setting </a></li>
                <li><a href = "logout_script.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
            </ul>
        </div>
    </div>
</div>
<br><br><br>
<div class="col-lg-offset-4 col-lg-3 container">
    <h3>Change Password</h3>
    <form action="settings_script.php" method="POST">
<!--                <div class="form-group">
                    <input type="password" class="form-control" name="old_password" placeholder="Old Password" required="true">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="password" placeholder="New Password" required="true">
                        </div>
        <div class="form-group">
                            <input type="password" class="form-control" name="password1" placeholder="Re-Enter New Password" required="true">
                        </div>
                        <input type="submit" value="Change" class="btn btn-primary">-->
<div class="form-group">
                            <input type="password" class="form-control" name="old-password"  placeholder="Old Password" required = "true">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="password" placeholder="New Password" required = "true">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="password1"  placeholder="Re-type New Password" required = "true">
                        </div>
                        <button type="submit" class="btn btn-primary">Change</button>
                        <?php
                        //echo "<br><br><b class='red'>" . $_GET['error'] . "</b>";
                        ?>
    </form>
</div>
<footer>
    <div class="container" style="height: 60px">
        <center>
            <p><h3>Copyright &copy; E-Store. All Rights Reserved  |  Contact Us: +91-123-000000</h3></p>	
        </center>
    </div>
</footer>
    </body>
</html>