<?php
$con = mysqli_connect("localhost:3308", "root", "", "estoremodel")or die($mysqli_error($con));
error_reporting(E_ALL ^ E_NOTICE);
session_start();
function logcheck(){
    // Redirects the user to products page if logged in.
if (isset($_SESSION['email'])) {
    header('location: home.php');
}
}
include 'model.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="css/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>
        <title>Contact Us || E-Store</title>
        <style>
            * {
  box-sizing: border-box;
  font-family: "Lato", sans-serif;
  margin: 0;
  padding: 0;
}
ul {
  list-style: none;
  padding-left: 0;
}
footer {
  background-color: #555;
  color: #bbb;
  line-height: 1.5;
}
footer a {
  text-decoration: none;
  color: #eee;
}
a:hover {
  text-decoration: underline;
    color: #eee;

}
.ft-title {
  color: #fff;
  font-family: "Merriweather", serif;
/*  font-size: 1.375rem;*/
  padding-bottom: 0.625rem;
}
.ft-main {
  padding-left: 1.25rem;
  display: flex;
  flex-wrap: wrap;
}
.ft-main-item {
  /*padding-left: 1.25rem;*/
  /*min-width: 12.5rem;*/
}

            </style>
    </head>
    <body>
        <div class="navbar  navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>                        
            </button>
            <a class="navbar-brand" href="index.php">E-Store</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav navbar-right">
                    <li><a href="signup.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                    <li><a href="#exampleModal" rel="tooltip" role="button" data-toggle="modal"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                    <li><a href = "about.php"><span class = "glyphicon glyphicon-tasks"></span> About Us </a></li>
                    <li class="active"><a href = "contact.php"><span class = "glyphicon glyphicon-phone"></span> Contact Us</a></li>
            </ul>
        </div>
    </div>
</div>
<br><br><br>

<div class="container">
    <div style="width: 80%; display: inline-block;">
        <h1>LIVE SUPPORT</h1>
        <h3>24 hours | 7 days a week | 365 days a year Live Technical Support</h3>
        <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem
        Ipsum is that it has a more-or-less normal distribution of letters . There are many variation of passage of Lorem Ipsum available , but the majority
        have suffered alternation in some form , by injected humour , or randomised words which don't look even slightly believable . If you are going to use
        a passage of Lorem Ipsum, you need to be sure there isn't anything embarrasing hidden in the middle of text.</p>
    </div>
    <div style="width: 15%; display: inline-table;">
        <img src="img/contact.png" class="img-responsive" alt="">
    </div>
</div>
<div class="container">
    <div style="display: inline-block; width: 59%">
        <h2>CONTACT US</h2>
        <form>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" name="name">
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="text" class="form-control" name="email">
            </div>
            <div class="form-group">
                <label for="messege">Messege:</label>
                <input type="text" style="height: 100px" class="form-control input-lg" name="messege">
            </div>
            <input type="submit" value="Submit" class="btn btn-primary">
        </form>
    </div>
    <div style="display: inline-block; width: 35%; padding-left: 5%">
        <h2>Company Information :</h2>
        <p>
            500 Lorem Ipsum Dolor Sit,<br>
            22-56-2-9 Sit Amet, Lorem,<br>
            USA<br>
            Phone:(00)222 666 444<br>
            Fax:(000)000 00 00 0<br>
            Email: info@mycompany.com<br>
            Follow on: Facebook, Twitter<br><br><br><br><br><br><br><br><br><br>
        </p>
    </div>
</div>

<footer>
  <!-- Footer main -->
  <section class="ft-main container">
      <div class="ft-main-item" style="width: 40%">
      <h2 class="ft-title">Information</h2>
      <ul>
          <li><a href="about.php">About Us</a></li>
          <li><a href="contact.php" class="active">Contact Us</a></li>
<!--        <li><a href="#">Pricing</a></li>
        <li><a href="#">Customers</a></li>
        <li><a href="#">Careers</a></li>-->
      </ul>
    </div>
    <div class="ft-main-item" style="width: 40%">
      <h2 class="ft-title">My Account</h2>
      <ul>
        <li><a href="#exampleModal" rel="tooltip" role="button" data-toggle="modal">Login</a></li>
        <!--<li><a href="login.php">Login</a></li>-->
        <li><a href="signup.php">Signup</a></li>
<!--        <li><a href="#">eBooks</a></li>
        <li><a href="#">Webinars</a></li>-->
      </ul>
    </div>
    <div class="ft-main-item" style="width: 20%">
      <h2 class="ft-title">Contact Us</h2>
      <ul>
        <li><a href="#">Contact: +91-123-000000</a></li>
<!--        <li><a href="#">Sales</a></li>
        <li><a href="#">Advertise</a></li>-->
      </ul>
    </div>
      </section>
<!--    <div class="ft-main-item">
      <h2 class="ft-title">Stay Updated</h2>
      <p>Subscribe to our newsletter to get our latest news.</p>
      <form>
        <input type="email" name="email" placeholder="Enter email address">
        <input type="submit" value="Subscribe">
      </form>
    </div>
  </section>

   Footer social 
  <section class="ft-social">
    <ul class="ft-social-list">
      <li><a href="#"><i class="fab fa-facebook"></i></a></li>
      <li><a href="#"><i class="fab fa-twitter"></i></a></li>
      <li><a href="#"><i class="fab fa-instagram"></i></a></li>
      <li><a href="#"><i class="fab fa-github"></i></a></li>
      <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
      <li><a href="#"><i class="fab fa-youtube"></i></a></li>
    </ul>
  </section>

   Footer legal 
  <section class="ft-legal">
    <ul class="ft-legal-list">
      <li><a href="#">Terms &amp; Conditions</a></li>
      <li><a href="#">Privacy Policy</a></li>
      <li>&copy; 2019 Copyright Nowrap Inc.</li>
    </ul>
  </section>-->
</footer>
    </body>
</html>