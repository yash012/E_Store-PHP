<?php
$con = mysqli_connect("localhost:3308", "root", "", "estoremodel")or die($mysqli_error($con));
error_reporting(E_ALL ^ E_NOTICE);
session_start();
if (!isset($_SESSION['email'])) {
    header('location: index.php');
}
$user_id = $_SESSION['user_id'];
$item_ids_string = $_GET['itemsid'];

//We will change the status of the items purchased by the user to 'Confirmed'
$query = "UPDATE users_items SET status='Confirmed' WHERE user_id=" . $user_id . " AND item_id IN (" . $item_ids_string . ") and status='Added to cart'";
mysqli_query($con, $query) or die($mysqli_error($con));
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="css/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>
        <style>
            footer {
  background-color: #555;
  color: #bbb;
  line-height: 1.5;
  bottom: 0;
  position: absolute;
  width: 100%;
}
        </style>
        <title>Success || E-Store</title>
    </head>
    <body>
        <div class="navbar  navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>                        
            </button>
            <a class="navbar-brand active active" href="home.php">E-Store</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="cart.php" class="active"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
                <li><a href = "setting.php"><span class = "glyphicon glyphicon-cog"></span> Setting </a></li>
                <li><a href = "logout_script.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
            </ul>
        </div>
    </div>
</div>
<br><br><br>
<div class="col-lg-offset-4 col-lg-4 container text-center">
    <p><br>Thankyou for ordering from E-Store. The order shell be delivered<br>
        to you shortly<br></p>
    <hr>
    <p>Order some more electronic items <a href="home.php">here</a></p>
</div>
<footer>
    <div class="container" style="height: 60px">
        <center>
            <p><h3>Copyright &copy; E-Store. All Rights Reserved  |  Contact Us: +91-123-000000</h3></p>	
        </center>
    </div>
</footer>
    </body>
</html>
    </body>
</html>