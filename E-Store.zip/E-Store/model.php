<!-- Button trigger modal -->
<!--<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Launch demo modal
</button>-->
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="display: inline">
          <span aria-hidden="true">&times;</span>
        </button>
        <h3 class="modal-title" id="exampleModalLabel">Login</h3>
        
        
      </div>
      <div class="modal-body">
            <p>Don't have an account?<a href="signup.php"> Register</a></p>
            <form role="form" action="login_submit.php" method="POST">
                <div class="form-group">
                            <input type="email" class="form-control" name="email" placeholder="Email" required="true">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="password" placeholder="Password" required="true">
                        </div>
<button type="submit" name="submit" class="btn btn-primary">Login</button>
<!--                <div class="form-group">
                    <input type="email" class="form-control"  placeholder="Email" name="e-mail" required = "true">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password" name="password" required = "true">
                </div>
                <button type="submit" name="submit" class="btn btn-primary">Login</button>--><br><br>
                <a href="#"> Forget Password</a>
            </form>                    
      </div>
<!--      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>-->
    </div>
  </div>
</div>


