<?php
$con = mysqli_connect("localhost:3308", "root", "", "estoremodel")or die($mysqli_error($con));
error_reporting(E_ALL ^ E_NOTICE);
session_start();
?>

<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
<!--        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/jquery-3.5.1.min.js"></script>-->
        
        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="css/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>
        <style>
            footer {
  background-color: #555;
  color: #bbb;
  line-height: 1.5;
}
        </style>
        <title>Home || E-Store</title>
    </head>
    <body>
<?php
        include 'check-if-added.php';
        ?>
        <div class="navbar  navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>                        
            </button>
            <a class="navbar-brand active" href="home.php">E-Store</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
                <li><a href = "setting.php"><span class = "glyphicon glyphicon-cog"></span> Setting </a></li>
                <li><a href = "logout_script.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
            </ul>
        </div>
    </div>
</div>
<br><br><br>


    
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#1</h6>
            </div>            
            <img src="img/Apple-iPhone-1st-gen-3.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 1st Generation</b><br>2MP Rear camera, 128MB DRAM, 16GB Internal Memory, 3.7 V 1400 mAh Lithium-ion battery. Rs 10,850.</p>         
                <p>
                    <?php
                                if (check_if_added_to_cart(1)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=1" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#2</h6>
            </div>            
            <img src="img/apple-iphone-3g-01.jpg" class="img-responsive" style='height:400px'  alt="">
            <div class="caption">
                <p><b>iPhone 3G</b><br>2MP Rear camera, 128MB DRAM, 16GB Internal Memory, 1150 mAh battery. Rs 7,400.<br></p>
                <p>
                    <?php
                                if (check_if_added_to_cart(2)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=2" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#3</h6>
            </div>            
            <img src="img/3gs.jpg" class="img-responsive" style='height:400px'  alt="">
            <div class="caption">
                    <p><b>iPhone 3GS</b><br>3 MPix with video (VGA at 30 fps) Rear camera, 256MB DRAM, 32GB Internal Memory, 1220 mAh battery. Rs 18,092.</p>
<p>
                    <?php 
                                if (check_if_added_to_cart(3)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=3" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#4</h6>
            </div>            
            <img src="img/iPhone-4.jpg" class="img-responsive"  style='height:400px' alt="">
            <div class="caption">
                    <p><b>iPhone 4</b><br>0.3MP Front Camera, 5MP Rear camera, 512MB DRAM, 32GB Internal Memory, 1,420 mAh battery. Rs 41,900.</p>            
<p>
                    <?php
                                if (check_if_added_to_cart(4)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=4" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#5</h6>
            </div>            
            <img src="img/iPhone-4s.jpg" class="img-responsive"  style='height:400px' alt="">
            <div class="caption">
                    <p><b>iPhone 4S</b><br>0.3MP Front Camera, 8MP Rear camera, 512MB DRAM, 64GB Internal Memory, 1430 mAh battery. Rs 50,432.</p>            
<p>
                    <?php
                                if (check_if_added_to_cart(5)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=5" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#6</h6>
            </div>            
            <img src="img/iphone-5.jpg" class="img-responsive"  style='height:400px' alt="">
            <div class="caption">
                    <p><b>iPhone 5</b><br>1.2MP Front Camera, 8MP Rear camera, 1GB RAM, 64GB Internal Memory, 1440 mAh battery. Rs 43,750.</p>            
<p>
                    <?php
                                if (check_if_added_to_cart(6)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=6" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#7</h6>
            </div>            
            <img src="img/iPhone-5c.jpeg" class="img-responsive"  style='height:400px' alt="">
            <div class="caption">
                    <p><b>iPhone 5C</b><br>1.2 MP Front Camera, 8MP Rear camera, 1GB RAM, 32GB Internal Memory, 1510 mAh battery. Rs 53,500.</p>            
<p>
                    <?php
                                if (check_if_added_to_cart(7)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=7" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#8</h6>
            </div>            
            <img src="img/apple-iphone-5s.jpg" class="img-responsive"  style='height:400px' alt="">
            <div class="caption">
                    <p><b>iPhone 5S</b><br>1.2 MP Front Camera, 8MP Rear camera, 1GB RAM, 64GB Internal Memory, 1560 mAh battery. Rs 49,500.</p>            
<p>
                    <?php
                                if (check_if_added_to_cart(8)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=8" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#9</h6>
            </div>            
            <img src="img/iphone-6.jpg" class="img-responsive"  style='height:400px' alt="">
            <div class="caption">
                  <p><b>iPhone 6</b><br>1.2MP Front Camera, 8MP Rear camera, 1GB RAM, 128GB Internal Memory, 1810 mAh battery. Rs 71,500.</p>              
<p>
                    <?php
                                if (check_if_added_to_cart(9)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=9" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#10</h6>
            </div>            
            <img src="img/iphone-6-plus.jpeg" class="img-responsive"  style='height:400px' alt="">
            <div class="caption">
                    <p><b>iPhone 6 Plus</b><br>1.2MP Front Camera, 8MP Rear camera, 1GB RAM, 128GB Internal Memory, 2,915 mA·h battery. Rs 48,999.</p>            
<p>
                    <?php
                                if (check_if_added_to_cart(10)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=10" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#11</h6>
            </div>            
            <img src="img/iphone-6s.jpeg" class="img-responsive"  style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 6S</b><br>5MP Front Camera, 12MP Rear camera, 2GB RAM, 128GB Internal Memory, 2750 mA·h battery. Rs 43,490.</p>                
<p>
                    <?php
                                if (check_if_added_to_cart(11)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=11" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#12</h6>
            </div>            
            <img src="img/iphone6splus.png" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 6S Plus</b><br>5MP Front Camera, 12MP Rear camera, 2GB RAM, 128GB Internal Memory, 2750 mA·h battery. Rs 49,990.</p>                
<p>
                    <?php
                                if (check_if_added_to_cart(12)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=12" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#13</h6>
            </div>            
            <img src="img/iphone-SE-1st.png" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone SE(1st generation)</b><br>1.2MP Front Camera, 12.2MP Rear camera, 2GB RAM, 128GB Internal Memory, 1624 mAh battery. Rs 19,999.</p>                
<p>
                    <?php
                                if (check_if_added_to_cart(13)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=13" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#14</h6>
            </div>            
            <img src="img/iphone7.png" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 7</b><br>7MP Front Camera, 12MP Rear camera, 2GB RAM, 256GB Internal Memory, 1960 mA·h battery. Rs 74,400.</p>                
<p>
                    <?php
                                if (check_if_added_to_cart(14)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=14" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#15</h6>
            </div>            
            <img src="img/ipnone7plus.png" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 7 Plus</b><br>7MP Front Camera, 12MP Rear camera, 3GB RAM, 256GB Internal Memory, 2900 mA·h battery. Rs 85,400.</p>                
<p>
                    <?php
                                if (check_if_added_to_cart(15)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=15" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#16</h6>
            </div>            
            <img src="img/iphone-8.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 8</b><br>7MP Front Camera, 12MP Rear camera, 2GB RAM, 256GB Internal Memory, 1821 mA·h battery. Rs 77,000.</p>                
<p>
                    <?php
                                if (check_if_added_to_cart(16)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=16" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#17</h6>
            </div>            
            <img src="img/iphone-8plus.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 8 Plus</b><br>7MP Front Camera, 12MP Rear camera, 3GB RAM, 256GB Internal Memory, 2691 mA·h battery. Rs 84,900.</p>                
<p>
                    <?php
                                if (check_if_added_to_cart(17)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=17" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#18</h6>
            </div>            
            <img src="img/iphonex.png" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone X</b><br>7MP Front Camera, 12MP Rear camera, 3GB RAM, 256GB Internal Memory, 2716 mA·h battery. Rs 69,999.</p>                
<p>
                    <?php
                                if (check_if_added_to_cart(18)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=18" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#19</h6>
            </div>            
            <img src="img/iphone-XS.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone XS</b><br>7MP Front Camera, 12MP Rear camera, 4GB RAM, 512GB Internal Memory, 2658 mA·h battery. Rs 1,14,900.</p>                
<p>
                    <?php
                                if (check_if_added_to_cart(19)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=19" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#20</h6>
            </div>            
            <img src="img/iphone-XS-max.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone XS Max</b><br>7MP Front Camera, 12MP Rear camera, 4GB RAM, 512GB Internal Memory, 3174 mA·h battery. Rs 1,44,900.</p>                
<p>
                    <?php
                                if (check_if_added_to_cart(20)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=20" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#21</h6>
            </div>            
            <img src="img/iphone-XR.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone XR</b><br>7MP Front Camera, 12MP Rear camera, 3GB RAM, 256GB Internal Memory, 2942 mA·h battery. Rs 91,900.</p>                
<p>
                    <?php
                                if (check_if_added_to_cart(21)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=21" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#22</h6>
            </div>            
            <img src="img/IPHONE-11.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 11</b><br>12MP Front Camera, 12MP Rear camera, 4GB RAM, 256GB Internal Memory, 3110 mAh battery. Rs 69,900.</p>                
<p>
                    <?php
                                if (check_if_added_to_cart(22)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=22" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#23</h6>
            </div>            
            <img src="img/refurb-iphone-11-pro.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 11 Pro</b><br>12MP Front Camera, 12MP Rear camera, 4GB RAM, 512GB Internal Memory, 3046 mAh battery. Rs 99,900.</p>                
<p>
                    <?php
                                if (check_if_added_to_cart(23)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=23" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#24</h6>
            </div>      
            <div class="pannel-body text-center">
                <img src="img/iphone-11pro-max.jpg" class="img-responsive text-center" style='height:400px' alt="">
            </div>
            <div class="caption">
                <p><b>iPhone 11 Pro Max</b><br>12MP Front Camera, 12MP Rear camera, 4GB RAM, 512GB Internal Memory, 3969 mAh battery. Rs 1,41,900.</p>
<p>
                    <?php
                                if (check_if_added_to_cart(24)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=24" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#25</h6>
            </div>            
            <img src="img/iphone-se-2.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone SE(2nd generation)</b><br>7MP Front Camera, 12MP Rear camera, 3GB RAM, 256GB Internal Memory, 1821 mAh battery. Rs 47,999.</p>                
<p>
                    <?php
                                if (check_if_added_to_cart(25)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=25" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#26</h6>
            </div>            
            <img src="img/iphone-12.png" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 12</b><br>12MP Front Camera, 12MP Rear camera, 4GB RAM, 256GB Internal Memory, 2,815 mAh battery. Rs 94,900.</p>                
<p>
                    <?php
                                if (check_if_added_to_cart(26)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=26" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#27</h6>
            </div>            
            <img src="img/iphone-12-mini.png" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 12 Mini</b><br>12MP Front Camera, 12MP Rear camera, 4GB RAM, 256GB Internal Memory, 2,227 mAh battery. Rs 84,900.</p>
<p>
                    <?php
                                if (check_if_added_to_cart(27)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=27" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#28</h6>
            </div>            
            <img src="img/iphone-12-pro.png" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 12 Pro</b><br>12MP Front Camera, 12MP Rear camera, 6GB RAM, 512GB Internal Memory, 2815 mAh battery. Rs 1,49,900.</p>                
<p>
                    <?php
                                if (check_if_added_to_cart(28)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=28" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#29</h6>
            </div>            
            <img src="img/iPhone_12_Pro_Max.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 12 Pro Max</b><br>12MP Front Camera, 12MP Rear camera, 6GB RAM, 512GB Internal Memory, 3687 mAh battery. Rs 1,59,900.</p>
<p>
                    <?php
                                if (check_if_added_to_cart(29)) { //This is same as if(check_if_added_to_cart != 0)?>
                                    <a href="#" class="btn btn-block btn-success" disabled>Added to cart</a>
                                <?php } else {
                                    ?>
                                    <a href="cart-add.php?id=29" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                                    <?php
                                }?></p>                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>#30</h6>
            </div>            
            <img src="img/iphone-13.jpg" class="img-responsive" style='height:420px' alt="">
            <div class="caption">
                <p><b>iPhone 13<br>Coming Soon</b></p>     
                <p><a href="success.php" role="button" class="btn btn-primary btn-block disabled">Add to cart</a></p>
                                
            </div>
        </div>
    </div>
</div>


<footer>
    <div class="container" style="height: 60px">
        <center>
            <p><h3>Copyright &copy; E-Store. All Rights Reserved  |  Contact Us: +91-123-000000</h3></p>	
        </center>
    </div>
</footer>
    </body>
</html>
