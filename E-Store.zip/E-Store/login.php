<?php
$con = mysqli_connect("localhost:3308", "root", "", "estore")or die($mysqli_error($con));
error_reporting(E_ALL ^ E_NOTICE);
session_start();
// Redirects the user to products page if logged in.
if (isset($_SESSION['email'])) {
    header('location: home.php');
}
?>
<html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="css/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>
        <title>Login || E-Store</title>
        <style>
            * {
  box-sizing: border-box;
  font-family: "Lato", sans-serif;
  margin: 0;
  padding: 0;
}
ul {
  list-style: none;
  padding-left: 0;
}
footer {
  background-color: #555;
  color: #bbb;
  line-height: 1.5;
  position: absolute;
  width: 100%;
  bottom: 0;
}
footer a {
  text-decoration: none;
  color: #eee;
}
a:hover {
  text-decoration: underline;
    color: #eee;

}
.ft-title {
  color: #fff;
  font-family: "Merriweather", serif;
/*  font-size: 1.375rem;*/
  padding-bottom: 0.625rem;
}
.ft-main {
  padding-left: 1.25rem;
  display: flex;
  flex-wrap: wrap;
}
.ft-main-item {
  /*padding-left: 1.25rem;*/
  /*min-width: 12.5rem;*/
}
</style>
    </head>

    <body>
        <div class="navbar  navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>                        
            </button>
            <a class="navbar-brand" href="index.php">E-Store</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav navbar-right">
                    <li><a href="signup.php"><span class="glyphicon glyphicon-user active"></span> Sign Up</a></li>
                    <li class="active"><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                    <li><a href = "about.php"><span class = "glyphicon glyphicon-tasks"></span> About Us </a></li>
                    <li><a href = "contact.php"><span class = "glyphicon glyphicon-phone"></span> Contact Us</a></li>
            </ul>
        </div>
    </div>
</div>
<br><br><br>
        <div id="content">
            <div class="container-fluid decor_bg" id="login-panel">
                <div class="row">
                    <div class="col-md-5 col-md-offset-3">
                        <div class="panel panel-default" >
                            <div class="panel-heading">
                                <h3>LOGIN</h3>
                            </div>
                            <div class="panel-body">
                                <p>Don't have an account?<a href="signup.php"> Register</a></p>
            <form role="form" action="login_submit.php" method="POST">
                <div class="form-group">
                            <input type="email" class="form-control" name="email" placeholder="Email" required="true">
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" name="password" placeholder="Password" required="true">
                        </div>
<!--<button type="submit" name="submit" class="btn btn-primary">Login</button>-->
<a href="login_submit.php">  <input class="submit" type="submit" value="Login"></a>
<!--                <div class="form-group">
                    <input type="email" class="form-control"  placeholder="Email" name="e-mail" required = "true">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password" name="password" required = "true">
                </div>
                <button type="submit" name="submit" class="btn btn-primary">Login</button>--><br><br>
                <a href="#"> Forget Password</a>
            </form>    
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
<footer>
  <!-- Footer main -->
  <section class="ft-main container">
      <div class="ft-main-item" style="width: 40%">
      <h2 class="ft-title">Information</h2>
      <ul>
          <li><a href="about.php">About Us</a></li>
        <li><a href="contact.php">Contact Us</a></li>
<!--        <li><a href="#">Pricing</a></li>
        <li><a href="#">Customers</a></li>
        <li><a href="#">Careers</a></li>-->
      </ul>
    </div>
    <div class="ft-main-item" style="width: 40%">
      <h2 class="ft-title">My Account</h2>
      <ul>
          <li><a href="#" class="active">Login</a></li>
        <li><a href="signup.php">Signup</a></li>
<!--        <li><a href="#">eBooks</a></li>
        <li><a href="#">Webinars</a></li>-->
      </ul>
    </div>
    <div class="ft-main-item" style="width: 20%">
      <h2 class="ft-title">Contact Us</h2>
      <ul>
        <li><a href="#">Contact: +91-123-000000</a></li>
<!--        <li><a href="#">Sales</a></li>
        <li><a href="#">Advertise</a></li>-->
      </ul>
    </div>
      </section>
<!--    <div class="ft-main-item">
      <h2 class="ft-title">Stay Updated</h2>
      <p>Subscribe to our newsletter to get our latest news.</p>
      <form>
        <input type="email" name="email" placeholder="Enter email address">
        <input type="submit" value="Subscribe">
      </form>
    </div>
  </section>

   Footer social 
  <section class="ft-social">
    <ul class="ft-social-list">
      <li><a href="#"><i class="fab fa-facebook"></i></a></li>
      <li><a href="#"><i class="fab fa-twitter"></i></a></li>
      <li><a href="#"><i class="fab fa-instagram"></i></a></li>
      <li><a href="#"><i class="fab fa-github"></i></a></li>
      <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
      <li><a href="#"><i class="fab fa-youtube"></i></a></li>
    </ul>
  </section>

   Footer legal 
  <section class="ft-legal">
    <ul class="ft-legal-list">
      <li><a href="#">Terms &amp; Conditions</a></li>
      <li><a href="#">Privacy Policy</a></li>
      <li>&copy; 2019 Copyright Nowrap Inc.</li>
    </ul>
  </section>-->
</footer>
    </body>
</html>
