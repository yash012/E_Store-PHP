<?php
$con = mysqli_connect("localhost:3308", "root", "", "estoremodel")or die($mysqli_error($con));
error_reporting(E_ALL ^ E_NOTICE);
session_start();
function logcheck(){
    // Redirects the user to products page if logged in.
if (isset($_SESSION['email'])) {
    header('location: home.php');
}
}
include 'model.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="css/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>
        <title>About Us || E-Store</title>
        <style>
            * {
  box-sizing: border-box;
  font-family: "Lato", sans-serif;
  margin: 0;
  padding: 0;
}
ul {
  list-style: none;
  padding-left: 0;
}
footer {
  background-color: #555;
  color: #bbb;
  line-height: 1.5;
}
footer a {
  text-decoration: none;
  color: #eee;
}
a:hover {
  text-decoration: underline;
    color: #eee;

}
.ft-title {
  color: #fff;
  font-family: "Merriweather", serif;
/*  font-size: 1.375rem;*/
  padding-bottom: 0.625rem;
}
.ft-main {
  padding-left: 1.25rem;
  display: flex;
  flex-wrap: wrap;
}
.ft-main-item {
  /*padding-left: 1.25rem;*/
  /*min-width: 12.5rem;*/
}

            </style>
    </head>
    <body>
    <div class="navbar  navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>                        
            </button>
            <a class="navbar-brand" href="index.php">E-Store</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav navbar-right">
                    <li><a href="signup.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                    <li><a href="#exampleModal" rel="tooltip" role="button" data-toggle="modal"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                    <li class="active"><a href = "#"><span class = "glyphicon glyphicon-tasks"></span> About Us </a></li>
                    <li><a href = "contact.php"><span class = "glyphicon glyphicon-phone"></span> Contact Us</a></li>
            </ul>
        </div>
    </div>
</div>
<br><br><br>

<div class="container">
    <div style="width: 35%;padding-right: 5%; display: inline-table">
        <h3>WHO WE ARE</h3>
        <img src="img/about-img.jpg" class="img-responsive" alt="" style="padding-right: 5%">
        <p>E-store is an Indian electronic commerce company with headquarters in Khategaon. It is the largest Internet-based retailer in the India E-Store started as an online blog, but
        soon diversified, selling mobile phones. E-Store also sells certain low-end product's like USB cables and other accessories. E-Store has separate retail websites for India, Nepal, Bhutan, Shri Lanka and Bangladesh.</p>
    </div>
    <div style="width: 34%;padding-right: 5%; display: inline-table">
        <h3>OUR HISTORY</h3>
        <a href="#">1998-</a>
        <p>The company was founded in 1998 spurred by what Velos called his "Initiating framework". which described his efforts as an initiate to participate in the internet buisness boom during that time in 
            1998, Velos left his employment as president of Ofcol & Co. and moved to Seatle. He began to work on a business plan for what would eventually become E-Store</p>
        <a href="#">2002-</a>
        <p>In January 2002. E-Store has received a funding of $12 million from Venture Partners and Indo-US Venture Partners</p>
        <a href="#">2008-</a>
        <p>In July 2008. the company raised a further $45 million from bessemer Venture Partners, along with existing investors Venture Partners and Indo-US Venture Partners</p>
        <a href="#">2015-</a>
        <p>E-Store received its 3rd round of $133 million on Feb-2015 The 3rd round of funding was led by Fcom with all the current institutional investors, including Kalaari Capital,Venture Partners. </p>
    </div>
    <div style="width: 30%; display: inline-table">
        <h3>OPPORTUNITIES</h3><br><br>
        <b>Available Roles</b>
        <p><br>
            1. Jr/Sr. Web Developer [Full Time Role + also available as a 6 Months Internship]<br><br>
            2. Business Apprentic [6 Months Internship]<br><br>
            3. Manager at backend operations [Full Time Role + also available as a 6 Months Internship]<br>
        </p>
    </div>
</div>

<footer>
  <!-- Footer main -->
  <section class="ft-main container">
      <div class="ft-main-item" style="width: 40%">
      <h2 class="ft-title">Information</h2>
      <ul>
          <li><a href="about.php" class="active">About Us</a></li>
        <li><a href="contact.php">Contact Us</a></li>
<!--        <li><a href="#">Pricing</a></li>
        <li><a href="#">Customers</a></li>
        <li><a href="#">Careers</a></li>-->
      </ul>
    </div>
    <div class="ft-main-item" style="width: 40%">
      <h2 class="ft-title">My Account</h2>
      <ul>
          <li><a href="#exampleModal" rel="tooltip" role="button" data-toggle="modal">Login</a></li>
        <li><a href="signup.php">Signup</a></li>
<!--        <li><a href="#">eBooks</a></li>
        <li><a href="#">Webinars</a></li>-->
      </ul>
    </div>
    <div class="ft-main-item" style="width: 20%">
      <h2 class="ft-title">Contact Us</h2>
      <ul>
        <li><a href="#">Contact: +91-123-000000</a></li>
<!--        <li><a href="#">Sales</a></li>
        <li><a href="#">Advertise</a></li>-->
      </ul>
    </div>
      </section>
<!--    <div class="ft-main-item">
      <h2 class="ft-title">Stay Updated</h2>
      <p>Subscribe to our newsletter to get our latest news.</p>
      <form>
        <input type="email" name="email" placeholder="Enter email address">
        <input type="submit" value="Subscribe">
      </form>
    </div>
  </section>

   Footer social 
  <section class="ft-social">
    <ul class="ft-social-list">
      <li><a href="#"><i class="fab fa-facebook"></i></a></li>
      <li><a href="#"><i class="fab fa-twitter"></i></a></li>
      <li><a href="#"><i class="fab fa-instagram"></i></a></li>
      <li><a href="#"><i class="fab fa-github"></i></a></li>
      <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
      <li><a href="#"><i class="fab fa-youtube"></i></a></li>
    </ul>
  </section>

   Footer legal 
  <section class="ft-legal">
    <ul class="ft-legal-list">
      <li><a href="#">Terms &amp; Conditions</a></li>
      <li><a href="#">Privacy Policy</a></li>
      <li>&copy; 2019 Copyright Nowrap Inc.</li>
    </ul>
  </section>-->
</footer>
    </body>
</html>

