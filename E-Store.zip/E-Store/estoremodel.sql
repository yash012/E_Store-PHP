-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Jul 15, 2021 at 09:57 AM
-- Server version: 8.0.18
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `estoremodel`
--

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
CREATE TABLE IF NOT EXISTS `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `price`) VALUES
(1, 'iPhone 1st Generation', 10850),
(2, 'iPhone 3G', 7400),
(3, 'iPhone 3GS', 18092),
(4, 'iPhone 4', 41900),
(5, 'iPhone 4S', 50432),
(6, 'iPhone 5', 43750),
(7, 'iPhone 5C', 53500),
(8, 'iPhone 5S', 49500),
(9, 'iPhone 6', 71500),
(10, 'iPhone 6 Plus', 48999),
(11, 'iPhone 6S', 43490),
(12, 'iPhone 6S Plus', 49990),
(13, 'iPhone SE(1st generation)', 19999),
(14, 'iPhone 7', 74400),
(15, 'iPhone 7 Plus', 85400),
(16, 'iPhone 8', 77000),
(17, 'iPhone 8 Plus', 84900),
(18, 'iPhone X', 69999),
(19, 'iPhone XS', 114900),
(20, 'iPhone XS Max', 144900),
(21, 'iPhone XR', 91900),
(22, 'iPhone 11', 69900),
(23, 'iPhone 11 Pro', 99900),
(24, 'iPhone 11 Pro Max', 141900),
(25, 'iPhone SE(2nd generation)', 47999),
(26, 'iPhone 12', 94900),
(27, 'iPhone 12 Mini', 84900),
(28, 'iPhone 12 Pro', 149900),
(29, 'iPhone 12 Pro Max', 159900),
(30, 'iPhone 13', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `password` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `contact` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `city` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `address` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `name`, `contact`, `city`, `address`) VALUES
(1, 'rathoreyash012@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Yash Rathore', '7024953252', 'Jabalpur', 'Room no. 8, Goverment Boys Hostel no. 5, Ranjhi, Jabalpur 482011');

-- --------------------------------------------------------

--
-- Table structure for table `users_items`
--

DROP TABLE IF EXISTS `users_items`;
CREATE TABLE IF NOT EXISTS `users_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('Added to cart','Confirm','','') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`,`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users_items`
--

INSERT INTO `users_items` (`id`, `item_id`, `user_id`, `status`) VALUES
(6, 29, 1, ''),
(3, 1, 1, ''),
(4, 4, 1, ''),
(7, 3, 1, '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
