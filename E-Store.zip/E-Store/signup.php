<?php
$con = mysqli_connect("localhost:3308", "root", "", "estoremodel")or die($mysqli_error($con));
error_reporting(E_ALL ^ E_NOTICE);
session_start();
if (isset($_SESSION['email'])) {
    header('location: home.php');
}
function logcheck(){
    // Redirects the user to products page if logged in.
if (isset($_SESSION['email'])) {
    header('location: home.php');
}
}
include 'model.php';
?>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="css/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>
        <title>Sign Up || E-Store</title>
        <style>
            * {
  box-sizing: border-box;
  font-family: "Lato", sans-serif;
  margin: 0;
  padding: 0;
}
ul {
  list-style: none;
  padding-left: 0;
}
footer {
  background-color: #555;
  color: #bbb;
  line-height: 1.5;
  position: absolute;
  width: 100%;
}
footer a {
  text-decoration: none;
  color: #eee;
}
a:hover {
  text-decoration: underline;
    color: #eee;

}
.ft-title {
  color: #fff;
  font-family: "Merriweather", serif;
/*  font-size: 1.375rem;*/
  padding-bottom: 0.625rem;
}
.ft-main {
  padding-left: 1.25rem;
  display: flex;
  flex-wrap: wrap;
}
.ft-main-item {
  /*padding-left: 1.25rem;*/
  /*min-width: 12.5rem;*/
}

            </style>
    </head>
    <body>
        <div class="navbar  navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>                        
            </button>
            <a class="navbar-brand" href="index.php">E-Store</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="signup.php" class="active"><span class="glyphicon glyphicon-user active"></span> Sign Up</a></li>
                    <li><a href="#exampleModal" rel="tooltip" role="button" data-toggle="modal"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                    <li><a href = "about.php"><span class = "glyphicon glyphicon-tasks"></span> About Us </a></li>
                    <li><a href = "contact.php"><span class = "glyphicon glyphicon-phone"></span> Contact Us</a></li>
            </ul>
        </div>
    </div>
</div>
<br><br><br>

<div class="container">
    <div style="display: inline-block; width: 59%">
        <img src="img/signuppage.jpg" class="img-responsive" alt="">
    </div>
    <div style="display: inline-block; width: 40%; padding-left: 10%">
        <h1>SIGN UP</h1>
        <form action="signup_script.php" method="POST">
<!--                        <div class="form-group">
                            <input type="text" class="form-control" name="name" placeholder="Name" required="true">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="email" placeholder="Email" required="true">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="password" placeholder="Password" required="true">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="contact" placeholder="Contact" required="true">
                            <?php if (isset($_GET['m2'])){ ?>
                                <script>alert('<?php echo $_GET['m2'];?>')</script>
                                    <?php } ?>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="city" placeholder="City" required="true">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="address" placeholder="Address" required="true">
                        </div>
                        
            <input type="submit" value="Submit" class="btn btn-primary" style="float: right">-->
            <div class="form-group">
                                <input class="form-control" placeholder="Name" name="name"  required = "true" pattern="^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$">
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control"  placeholder="Email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"  name="e-mail" required = "true"><?php //echo $_GET['m1']; ?>
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" placeholder="Password" pattern=".{6,}" name="password" required = "true">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control"  placeholder="Contact" maxlength="10" size="10" name="contact" required = "true">
                                    <?php if (isset($_GET['m2'])){ ?>
                                <script>alert('<?php echo $_GET['m2'];?>')</script>
                                    <?php } ?>
                            </div>
                            <div class="form-group">
                                <input  type="text" class="form-control"  placeholder="City" name="city" required = "true">
                            </div>
                            <div class="form-group">
                                <input  type="text" class="form-control"  placeholder="Address" name="address" required = "true">
                            </div>
                            <button type="submit" name="submit" class="btn btn-primary" style="float: right">Submit</button>
        </form>
        </br></br></br></br></br></br></br>
    </div>
</div>
<footer>
  <!-- Footer main -->
  <section class="ft-main container">
      <div class="ft-main-item" style="width: 40%">
      <h2 class="ft-title">Information</h2>
      <ul>
          <li><a href="about.php">About Us</a></li>
        <li><a href="contact.php">Contact Us</a></li>
<!--        <li><a href="#">Pricing</a></li>
        <li><a href="#">Customers</a></li>
        <li><a href="#">Careers</a></li>-->
      </ul>
    </div>
    <div class="ft-main-item" style="width: 40%">
      <h2 class="ft-title">My Account</h2>
      <ul>
        <li><a href="#exampleModal" rel="tooltip" role="button" data-toggle="modal">Login</a></li>
        <li class="active"><a href="signup.php">Signup</a></li>
<!--        <li><a href="#">eBooks</a></li>
        <li><a href="#">Webinars</a></li>-->
      </ul>
    </div>
    <div class="ft-main-item" style="width: 20%">
      <h2 class="ft-title">Contact Us</h2>
      <ul>
        <li><a href="#">Contact: +91-123-000000</a></li>
<!--        <li><a href="#">Sales</a></li>
        <li><a href="#">Advertise</a></li>-->
      </ul>
    </div>
      </section>
<!--    <div class="ft-main-item">
      <h2 class="ft-title">Stay Updated</h2>
      <p>Subscribe to our newsletter to get our latest news.</p>
      <form>
        <input type="email" name="email" placeholder="Enter email address">
        <input type="submit" value="Subscribe">
      </form>
    </div>
  </section>

   Footer social 
  <section class="ft-social">
    <ul class="ft-social-list">
      <li><a href="#"><i class="fab fa-facebook"></i></a></li>
      <li><a href="#"><i class="fab fa-twitter"></i></a></li>
      <li><a href="#"><i class="fab fa-instagram"></i></a></li>
      <li><a href="#"><i class="fab fa-github"></i></a></li>
      <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
      <li><a href="#"><i class="fab fa-youtube"></i></a></li>
    </ul>
  </section>

   Footer legal 
  <section class="ft-legal">
    <ul class="ft-legal-list">
      <li><a href="#">Terms &amp; Conditions</a></li>
      <li><a href="#">Privacy Policy</a></li>
      <li>&copy; 2019 Copyright Nowrap Inc.</li>
    </ul>
  </section>-->
</footer>
    </body>
</html>