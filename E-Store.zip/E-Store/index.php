<?php
$con = mysqli_connect("localhost:3308", "root", "", "estoremodel")or die($mysqli_error($con));
error_reporting(E_ALL ^ E_NOTICE);
session_start();
// Redirects the user to products page if he/she is logged in.
if (isset($_SESSION['email'])) {
  header('location: home.php');
}
function logcheck(){
    // Redirects the user to products page if logged in.
if (isset($_SESSION['email'])) {
    header('location: home.php');
}
}
include 'model.php';
?>

<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
<!--        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/jquery-3.5.1.min.js"></script>-->
        
        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="css/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>
        <style>
            * {
  box-sizing: border-box;
  font-family: "Lato", sans-serif;
  margin: 0;
  padding: 0;
}
ul {
  list-style: none;
  padding-left: 0;
}
footer {
  background-color: #555;
  color: #bbb;
  line-height: 1.5;
}
footer a {
  text-decoration: none;
  color: #eee;
}
a:hover {
  text-decoration: underline;
    color: #eee;

}
.ft-title {
  color: #fff;
  font-family: "Merriweather", serif;
/*  font-size: 1.375rem;*/
  padding-bottom: 0.625rem;
}
.ft-main {
  padding-left: 1.25rem;
  display: flex;
  flex-wrap: wrap;
}
.ft-main-item {
  /*padding-left: 1.25rem;*/
  /*min-width: 12.5rem;*/
}

            </style>
        <title>Welcome || E-Store</title>
<!--        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"
        integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI"
        crossorigin="anonymous"></script>-->
    </head>
    <body>
<!--        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbarSupportedContent">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>                        
            </button>
            <a class="navbar-brand" href="#">E-Store</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
        </div>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav navbar-right">
                 me-auto mb-2 mb-lg-0
              <li class="nav-item">
                    <a href="signup.php" class="nav-link"><span class="glyphicon glyphicon-user"></span> Sign Up</a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link"><span class="glyphicon glyphicon-log-in"></span> Login</a>
              </li>
              <li>
                  <a href = "about.php" class="nav-link"><span class = "glyphicon glyphicon-tasks"></span> About Us </a>
              </li>
              <li class="nav-item" >
                  <a href = "contact.php" class="nav-link"><span class = "glyphicon glyphicon-phone"></span> Contact Us</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>-->

<!--<nav class="navbar navbar-dark bg-dark navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            
            <a class="navbar-brand" href="index.php">Lifestyle Store</a>
            <button type="button" class="navbar-toggle navbar-right" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>                        
            </button>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav navbar-right">
                <li class="nav-item"><a href="signup.php" class="nav-link"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                    <li class="nav-item"><a href="#" class="nav-link"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                    <li class="nav-item"><a href = "about.php" class="nav-link"><span class = "glyphicon glyphicon-tasks"></span> About Us </a></li>
                    <li class="nav-item"><a href = "contact.php" class="nav-link"><span class = "glyphicon glyphicon-phone"></span> Contact Us</a></li>
            </ul>
        </div>
    </div>
</nav>-->
        <div class="navbar  navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>                        
            </button>
            <a class="navbar-brand active" href="index.php">E-Store</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav navbar-right">
                    <li><a href="signup.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                    <li><a href="#exampleModal" rel="tooltip" role="button" data-toggle="modal"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                    <li><a href = "about.php" class="btn"><span class = "glyphicon glyphicon-tasks"></span> About Us </a></li>
                    <li><a href = "contact.php"><span class = "glyphicon glyphicon-phone"></span> Contact Us</a></li>
            </ul>
        </div>
    </div>
</div>
<br><br><br>
  
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 1</h6>
            </div>            
            <img src="img/Apple-iPhone-1st-gen-3.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 1st Generation</b><br>2MP Rear camera, 128MB DRAM, 16GB Internal Memory, 3.7 V 1400 mAh Lithium-ion battery. Rs 10,850.</p>         
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 2</h6>
            </div>            
            <img src="img/apple-iphone-3g-01.jpg" class="img-responsive" style='height:400px'  alt="">
            <div class="caption">
                <p><b>iPhone 3G</b><br>2MP Rear camera, 128MB DRAM, 16GB Internal Memory, 1150 mAh battery. Rs 7,400.<br></p>
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 3</h6>
            </div>            
            <img src="img/3gs.jpg" class="img-responsive" style='height:400px'  alt="">
            <div class="caption">
                    <p><b>iPhone 3GS</b><br>3 MPix with video (VGA at 30 fps) Rear camera, 256MB DRAM, 32GB Internal Memory, 1220 mAh battery. Rs 18,092.</p>
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 4</h6>
            </div>            
            <img src="img/iPhone-4.jpg" class="img-responsive"  style='height:400px' alt="">
            <div class="caption">
                    <p><b>iPhone 4</b><br>0.3MP Front Camera, 5MP Rear camera, 512MB DRAM, 32GB Internal Memory, 1,420 mAh battery. Rs 41,900.</p>            
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 5</h6>
            </div>            
            <img src="img/iPhone-4s.jpg" class="img-responsive"  style='height:400px' alt="">
            <div class="caption">
                    <p><b>iPhone 4S</b><br>0.3MP Front Camera, 8MP Rear camera, 512MB DRAM, 64GB Internal Memory, 1430 mAh battery. Rs 50,432.</p>            
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 6</h6>
            </div>            
            <img src="img/iphone-5.jpg" class="img-responsive"  style='height:400px' alt="">
            <div class="caption">
                    <p><b>iPhone 5</b><br>1.2MP Front Camera, 8MP Rear camera, 1GB RAM, 64GB Internal Memory, 1440 mAh battery. Rs 43,750.</p>            
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 7</h6>
            </div>            
            <img src="img/iPhone-5c.jpeg" class="img-responsive"  style='height:400px' alt="">
            <div class="caption">
                    <p><b>iPhone 5C</b><br>1.2 MP Front Camera, 8MP Rear camera, 1GB RAM, 32GB Internal Memory, 1510 mAh battery. Rs 53,500.</p>            
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 8</h6>
            </div>            
            <img src="img/apple-iphone-5s.jpg" class="img-responsive"  style='height:400px' alt="">
            <div class="caption">
                    <p><b>iPhone 5S</b><br>1.2 MP Front Camera, 8MP Rear camera, 1GB RAM, 64GB Internal Memory, 1560 mAh battery. Rs 49,500.</p>            
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 9</h6>
            </div>            
            <img src="img/iphone-6.jpg" class="img-responsive"  style='height:400px' alt="">
            <div class="caption">
                  <p><b>iPhone 6</b><br>1.2MP Front Camera, 8MP Rear camera, 1GB RAM, 128GB Internal Memory, 1810 mAh battery. Rs 71,500.</p>              
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 10</h6>
            </div>            
            <img src="img/iphone-6-plus.jpeg" class="img-responsive"  style='height:400px' alt="">
            <div class="caption">
                    <p><b>iPhone 6 Plus</b><br>1.2MP Front Camera, 8MP Rear camera, 1GB RAM, 128GB Internal Memory, 2,915 mA·h battery. Rs 48,999.</p>            
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 11</h6>
            </div>            
            <img src="img/iphone-6s.jpeg" class="img-responsive"  style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 6S</b><br>5MP Front Camera, 12MP Rear camera, 2GB RAM, 128GB Internal Memory, 2750 mA·h battery. Rs 43,490.</p>                
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 12</h6>
            </div>            
            <img src="img/iphone6splus.png" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 6S Plus</b><br>5MP Front Camera, 12MP Rear camera, 2GB RAM, 128GB Internal Memory, 2750 mA·h battery. Rs 49,990.</p>                
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 13</h6>
            </div>            
            <img src="img/iphone-SE-1st.png" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone SE(1st generation)</b><br>1.2MP Front Camera, 12.2MP Rear camera, 2GB RAM, 128GB Internal Memory, 1624 mAh battery. Rs 19,999.</p>                
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 14</h6>
            </div>            
            <img src="img/iphone7.png" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 7</b><br>7MP Front Camera, 12MP Rear camera, 2GB RAM, 256GB Internal Memory, 1960 mA·h battery. Rs 74,400.</p>                
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 15</h6>
            </div>            
            <img src="img/ipnone7plus.png" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 7 Plus</b><br>7MP Front Camera, 12MP Rear camera, 3GB RAM, 256GB Internal Memory, 2900 mA·h battery. Rs 85,400.</p>                
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 16</h6>
            </div>            
            <img src="img/iphone-8.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 8</b><br>7MP Front Camera, 12MP Rear camera, 2GB RAM, 256GB Internal Memory, 1821 mA·h battery. Rs 77,000.</p>                
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 17</h6>
            </div>            
            <img src="img/iphone-8plus.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 8 Plus</b><br>7MP Front Camera, 12MP Rear camera, 3GB RAM, 256GB Internal Memory, 2691 mA·h battery. Rs 84,900.</p>                
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 18</h6>
            </div>            
            <img src="img/iphonex.png" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone X</b><br>7MP Front Camera, 12MP Rear camera, 3GB RAM, 256GB Internal Memory, 2716 mA·h battery. Rs 69,999.</p>                
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 19</h6>
            </div>            
            <img src="img/iphone-XS.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone XS</b><br>7MP Front Camera, 12MP Rear camera, 4GB RAM, 512GB Internal Memory, 2658 mA·h battery. Rs 1,14,900.</p>                
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 20</h6>
            </div>            
            <img src="img/iphone-XS-max.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone XS Max</b><br>7MP Front Camera, 12MP Rear camera, 4GB RAM, 512GB Internal Memory, 3174 mA·h battery. Rs 1,44,900.</p>                
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 21</h6>
            </div>            
            <img src="img/iphone-XR.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone XR</b><br>7MP Front Camera, 12MP Rear camera, 3GB RAM, 256GB Internal Memory, 2942 mA·h battery. Rs 91,900.</p>                
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 22</h6>
            </div>            
            <img src="img/IPHONE-11.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 11</b><br>12MP Front Camera, 12MP Rear camera, 4GB RAM, 256GB Internal Memory, 3110 mAh battery. Rs 69,900.</p>                
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 23</h6>
            </div>            
            <img src="img/refurb-iphone-11-pro.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 11 Pro</b><br>12MP Front Camera, 12MP Rear camera, 4GB RAM, 512GB Internal Memory, 3046 mAh battery. Rs 99,900.</p>                
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 24</h6>
            </div>      
            <div class="pannel-body text-center">
                <img src="img/iphone-11pro-max.jpg" class="img-responsive text-center" style='height:400px' alt="">
            </div>
            <div class="caption">
                <p><b>iPhone 11 Pro Max</b><br>12MP Front Camera, 12MP Rear camera, 4GB RAM, 512GB Internal Memory, 3969 mAh battery. Rs 1,41,900.</p>
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 25</h6>
            </div>            
            <img src="img/iphone-se-2.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone SE(2nd generation)</b><br>7MP Front Camera, 12MP Rear camera, 3GB RAM, 256GB Internal Memory, 1821 mAh battery. Rs 47,999.</p>                
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 26</h6>
            </div>            
            <img src="img/iphone-12.png" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 12</b><br>12MP Front Camera, 12MP Rear camera, 4GB RAM, 256GB Internal Memory, 2,815 mAh battery. Rs 94,900.</p>                
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 27</h6>
            </div>            
            <img src="img/iphone-12-mini.png" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 12 Mini</b><br>12MP Front Camera, 12MP Rear camera, 4GB RAM, 256GB Internal Memory, 2,227 mAh battery. Rs 84,900.</p>
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
</div>
<div class="row text-center" id="">
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 28</h6>
            </div>            
            <img src="img/iphone-12-pro.png" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 12 Pro</b><br>12MP Front Camera, 12MP Rear camera, 6GB RAM, 512GB Internal Memory, 2815 mAh battery. Rs 1,49,900.</p>                
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 29</h6>
            </div>            
            <img src="img/iPhone_12_Pro_Max.jpg" class="img-responsive" style='height:400px' alt="">
            <div class="caption">
                <p><b>iPhone 12 Pro Max</b><br>12MP Front Camera, 12MP Rear camera, 6GB RAM, 512GB Internal Memory, 3687 mAh battery. Rs 1,59,900.</p>
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 home-feature">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h6>Mobile 30</h6>
            </div>            
            <img src="img/iphone-13.jpg" class="img-responsive" style='height:420px' alt="">
            <div class="caption">
                <p><b>iPhone 13<br>Coming Soon</b></p>     
                <p><a data-toggle="modal" data-target="#exampleModal" role="button" class="btn btn-primary btn-block disabled">Buy Now</a></p>
                                
            </div>
        </div>
    </div>
</div>


<footer>
  <!-- Footer main -->
  <section class="ft-main container">
      <div class="ft-main-item" style="width: 40%">
      <h2 class="ft-title">Information</h2>
      <ul>
          <li><a href="about.php">About Us</a></li>
        <li><a href="contact.php">Contact Us</a></li>
<!--        <li><a href="#">Pricing</a></li>
        <li><a href="#">Customers</a></li>
        <li><a href="#">Careers</a></li>-->
      </ul>
    </div>
    <div class="ft-main-item" style="width: 40%">
      <h2 class="ft-title">My Account</h2>
      <ul>
        <li><a href="#exampleModal" rel="tooltip" role="button" data-toggle="modal">Login</a></li>
        <li><a href="signup.php">Signup</a></li>
<!--        <li><a href="#">eBooks</a></li>
        <li><a href="#">Webinars</a></li>-->
      </ul>
    </div>
    <div class="ft-main-item" style="width: 20%">
      <h2 class="ft-title">Contact Us</h2>
      <ul>
        <li><a href="#">Contact: +91-123-000000</a></li>
<!--        <li><a href="#">Sales</a></li>
        <li><a href="#">Advertise</a></li>-->
      </ul>
    </div>
      </section>
<!--    <div class="ft-main-item">
      <h2 class="ft-title">Stay Updated</h2>
      <p>Subscribe to our newsletter to get our latest news.</p>
      <form>
        <input type="email" name="email" placeholder="Enter email address">
        <input type="submit" value="Subscribe">
      </form>
    </div>
  </section>

   Footer social 
  <section class="ft-social">
    <ul class="ft-social-list">
      <li><a href="#"><i class="fab fa-facebook"></i></a></li>
      <li><a href="#"><i class="fab fa-twitter"></i></a></li>
      <li><a href="#"><i class="fab fa-instagram"></i></a></li>
      <li><a href="#"><i class="fab fa-github"></i></a></li>
      <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
      <li><a href="#"><i class="fab fa-youtube"></i></a></li>
    </ul>
  </section>

   Footer legal 
  <section class="ft-legal">
    <ul class="ft-legal-list">
      <li><a href="#">Terms &amp; Conditions</a></li>
      <li><a href="#">Privacy Policy</a></li>
      <li>&copy; 2019 Copyright Nowrap Inc.</li>
    </ul>
  </section>-->
</footer>
    </body>
</html>
